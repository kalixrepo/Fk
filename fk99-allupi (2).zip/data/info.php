<?php $infoArray = array (
  'username' => 'rohan',
  'password' => 'webs',
); ?>