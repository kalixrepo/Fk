<?php
header("Location: ./fk99-allupi/");
exit();
?>